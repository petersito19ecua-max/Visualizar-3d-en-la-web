<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Agregar Libro</title>
</head>
<body>
    <h1>Agregar Nuevo Libro</h1>
    <form method="POST">
        <label>Título: <input type="text" name="titulo" required></label><br><br>
        <label>Autor: <input type="text" name="autor" required></label><br><br>
        <label>ISBN: <input type="text" name="isbn" required></label><br><br>
        <button type="submit">Guardar Libro</button>
    </form>
    <br>
    <a href="index.php?accion=listar_libros">Volver a la lista</a>
</body>
</html>