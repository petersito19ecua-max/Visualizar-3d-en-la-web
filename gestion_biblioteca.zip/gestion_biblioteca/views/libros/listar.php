<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Lista de Libros</title>
    <link rel="stylesheet" href="../../styles.css">
</head>
<body>
    <h1>Libros en la Biblioteca</h1>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>Título</th>
            <th>Autor</th>
            <th>ISBN</th>
            <th>Disponible</th>
        </tr>
        <?php foreach ($libros as $libro): ?>
        <tr>
            <td><?= $libro['Id'] ?></td>
            <td><?= htmlspecialchars($libro['Title']) ?></td>
            <td><?= htmlspecialchars($libro['Author']) ?></td>
            <td><?= $libro['ISBN'] ?></td>
            <td><?= $libro['Available'] ? 'Sí' : 'No' ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <br>
    <a href="index.php?accion=agregar_libro">Agregar Nuevo Libro</a> |
    <a href="index.php?accion=listar_prestamos">Ver Préstamos</a> |
    <a href="index.php?accion=listar_usuarios">Ver Usuarios registrados</a>
</body>
</html>