<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Préstamos</title>
</head>
<body>
    <h1>Préstamos Activos</h1>

    <table border="1">
        <tr>
            <th>ID</th>
            <th>Libro</th>
            <th>Usuario</th>
            <th>Fecha Préstamo</th>
            <th>Devuelto</th>
        </tr>
        <?php foreach ($prestamos as $p): ?>
        <tr>
            <td><?= $p['Id'] ?></td>
            <td><?= htmlspecialchars($p['Titulo']) ?></td>
            <td><?= htmlspecialchars($p['Nombre']) ?></td>
            <td><?= $p['FechaPrestamo'] ?></td>
            <td><?= $p['FechaDevolucion'] ? $p['FechaDevolucion'] : 'Pendiente' ?></td>
        </tr>
        <?php endforeach; ?>
    </table>

    <h2>Realizar Préstamo</h2>
    <form method="POST" action="index.php?accion=prestar">
        <label>Libro:
            <select name="libro_id" required>
                <?php foreach ($libros as $libro): ?>
                    <?php if ($libro['Disponible']): ?>
                        <option value="<?= $libro['Id'] ?>"><?= htmlspecialchars($libro['Titulo']) ?></option>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>
        </label><br><br>

        <label>Usuario:
            <select name="usuario_id" required>
                <?php foreach ($usuarios as $usuario): ?>
                    <option value="<?= $usuario['Id'] ?>"><?= htmlspecialchars($usuario['Nombre']) ?></option>
                <?php endforeach; ?>
            </select>
        </label><br><br>

        <button type="submit">Prestar Libro</button>
    </form>

    <br>
    <a href="index.php?accion=listar_libros">Volver a Libros</a>
</body>
</html>