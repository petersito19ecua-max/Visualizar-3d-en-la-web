<?php
require_once(__DIR__ . '/../config/db.php');

class LibroModel {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance()->getConnection();
    }

    public function obtenerTodos() {
        $sql = "SELECT * FROM Books ORDER BY Title";
        $stmt = sqlsrv_query($this->conn, $sql);

        $libros = [];
        if ($stmt !== false) {
            while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
                $libros[] = $row;
            }
        }
        return $libros;
    }

    public function agregar($titulo, $autor, $isbn) {
        $sql = "INSERT INTO Books (Title, Author, ISBN) VALUES (?, ?, ?)";
        $params = [$titulo, $autor, $isbn];
        $stmt = sqlsrv_query($this->conn, $sql, $params);
        return $stmt !== false;
    }

    public function actualizarDisponibilidad($idLibro, $disponible) {
        $sql = "UPDATE Books SET Available = ? WHERE Id = ?";
        $params = [$disponible, $idLibro];
        $stmt = sqlsrv_query($this->conn, $sql, $params);
        return $stmt !== false;
    }

    public function obtenerDisponibles() {
        $sql = "SELECT Id, Title FROM Books WHERE Available = 1 ORDER BY Title";
        $stmt = sqlsrv_query($this->conn, $sql);

        $libros = [];
        if ($stmt !== false) {
            while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
                $libros[] = $row;
            }
        }

        return $libros;
    }
}
?>