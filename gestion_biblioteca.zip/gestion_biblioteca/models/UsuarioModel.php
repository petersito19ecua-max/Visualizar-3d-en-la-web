<?php
require_once(__DIR__ . '/../config/db.php');

class UsuarioModel {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance()->getConnection();
    }

    public function autenticar($email, $password) {
        $sql = "SELECT * FROM Users WHERE Email = ? AND Password = ?";
        $params = [$email, $password];
        $stmt = sqlsrv_query($this->conn, $sql, $params);

        if ($stmt !== false && $row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
            return $row;
        }

        return null;
    }

    public function obtenerTodos() {
        $sql = "SELECT * FROM Users";
        $stmt = sqlsrv_query($this->conn, $sql);

        $usuarios = [];
        if ($stmt !== false) {
            while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
                $usuarios[] = $row;
            }
        }

        return $usuarios;
    }
}
?>