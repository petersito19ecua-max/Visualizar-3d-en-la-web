<?php
require_once(__DIR__ . '/../config/db.php');

class PrestamoModel {
    private $conn;

    public function __construct() {
        $this->conn = Database::getInstance()->getConnection(); // ✅ método correcto
    }

    public function obtenerTodos() {
        $sql = "
            SELECT p.Id, l.Titulo, u.Nombre, p.FechaPrestamo, p.FechaDevolucion 
            FROM Prestamos p
            JOIN Libros l ON p.LibroId = l.Id
            JOIN Usuarios u ON p.UsuarioId = u.Id
            ORDER BY p.FechaPrestamo DESC
        ";

        $stmt = sqlsrv_query($this->conn, $sql);
        $prestamos = [];

        if ($stmt !== false) {
            while ($row = sqlsrv_fetch_array($stmt, SQLSRV_FETCH_ASSOC)) {
                $prestamos[] = $row;
            }
        }

        return $prestamos;
    }

    public function registrar($libroId, $usuarioId, $fechaPrestamo) {
        $sql = "INSERT INTO Prestamos (LibroId, UsuarioId, FechaPrestamo) VALUES (?, ?, ?)";
        $params = [$libroId, $usuarioId, $fechaPrestamo];
        $stmt = sqlsrv_query($this->conn, $sql, $params);
        return $stmt !== false;
    }
}
?>