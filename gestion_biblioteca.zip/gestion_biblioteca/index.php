<?php
require_once 'controllers/AuthController.php';
require_once 'controllers/LibroController.php';
require_once 'controllers/PrestamoController.php';
require_once 'controllers/UsuarioController.php'; // ✅ nuevo controlador

$accion = $_GET['accion'] ?? 'listar_libros';

switch ($accion) {
    
    case 'login':
        $controlador = new AuthController();
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $controlador->login();
        } else {
            $controlador->loginForm();
        }
        break;

    case 'logout':
        $controlador = new AuthController();
        $controlador->logout();
        break;
    
    case 'listar_libros':
        $controlador = new LibroController();
        $controlador->listar();
        break;

    case 'agregar_libro':
        $controlador = new LibroController();
        $controlador->agregar();
        break;

    case 'listar_prestamos':
        $controlador = new PrestamoController();
        $controlador->listar();
        break;

    case 'prestar':
        $controlador = new PrestamoController();
        $controlador->prestar();
        break;

    case 'listar_usuarios': // ✅ nueva acción
        $controlador = new UsuarioController();
        $controlador->listar();
        break;

    default:
        echo "<h1>Página no encontrada</h1>";
        break;
}
?>