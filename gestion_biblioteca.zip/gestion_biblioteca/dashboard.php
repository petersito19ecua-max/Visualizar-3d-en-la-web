<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header('Location: index.php?accion=login');
    exit;
}

$usuario = $_SESSION['usuario'];
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel</title>
</head>
<body>
    <h1>Bienvenido, <?= htmlspecialchars($usuario['Name']) ?></h1>
    <p>Rol: <?= $usuario['Role'] ?></p>

    <?php if ($usuario['Role'] === 'admin'): ?>
        <a href="index.php?accion=listar_libros">Gestionar Libros</a><br>
        <a href="index.php?accion=listar_usuarios">Ver Usuarios</a><br>
    <?php else: ?>
        <a href="index.php?accion=listar_prestamos">Mis Préstamos</a><br>
    <?php endif; ?>

    <br><a href="index.php?accion=logout">Cerrar sesión</a>
</body>
</html>