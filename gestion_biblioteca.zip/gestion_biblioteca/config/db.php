<?php
class Database {
    private static $instance = null;
    private $conn;

    private $serverName = "localhost\\SQLEXPRESS"; // Cambia si usas una instancia específica
    private $connectionOptions = array(
    "Database" => "biblioteca", // nombre de tu base de datos
    "Uid" => "sa",
    "PWD" => "admin",
    "TrustServerCertificate" => true,
    "CharacterSet" => "UTF-8"
);


    private function __construct() {
        $this->conn = sqlsrv_connect($this->serverName, $this->connectionOptions);
        if ($this->conn === false) {
            die("Error de conexión: " . print_r(sqlsrv_errors(), true));
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new Database();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->conn;
    }
}
?>