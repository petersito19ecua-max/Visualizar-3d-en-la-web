<?php
require_once(__DIR__ . '/../models/UsuarioModel.php');

class UsuarioController {
    public function listar() {
        $usuarioModel = new UsuarioModel();
        $usuarios = $usuarioModel->obtenerTodos();
        require_once(__DIR__ . '/../views/usuarios/listar.php');
    }
}
?>