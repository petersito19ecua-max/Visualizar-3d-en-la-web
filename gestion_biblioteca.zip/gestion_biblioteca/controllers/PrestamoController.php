<?php
require_once __DIR__ . '/../models/PrestamoModel.php';
require_once(__DIR__ . '/../models/LibroModel.php');
require_once(__DIR__ . '/../models/UsuarioModel.php');

class PrestamoController {
    private $prestamoModel;
    private $libroModel;
    private $usuarioModel;

    public function __construct() {
        $this->prestamoModel = new PrestamoModel();
        $this->libroModel = new LibroModel();
        $this->usuarioModel = new UsuarioModel();
    }

    public function listar() {
        $prestamos = $this->prestamoModel->obtenerTodos();
        $libros = $this->libroModel->obtenerDisponibles();
        $usuarios = $this->usuarioModel->obtenerTodos();
        require_once(__DIR__ . '/../views/prestamos/listar.php'); // ✅
    }

    public function prestar() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $libroId = $_POST['libro_id'];
            $usuarioId = $_POST['usuario_id'];
            $fecha = date('Y-m-d');

            if ($this->prestamoModel->registrar($libroId, $usuarioId, $fecha) &&
                $this->libroModel->actualizarDisponibilidad($libroId, 0)) {
                header('Location: index.php?accion=listar_prestamos');
                exit;
            } else {
                echo "Error al realizar el préstamo.";
            }
        }
    }
}
?>