<?php
require_once(__DIR__ . '/../models/UsuarioModel.php');
session_start();

class AuthController {
    public function loginForm() {
        require_once(__DIR__ . '/../views/auth/login.php');
    }

    public function login() {
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';

        $usuarioModel = new UsuarioModel();
        $usuario = $usuarioModel->autenticar($email, $password);

        if ($usuario) {
            $_SESSION['usuario'] = $usuario;
            header('Location: dashboard.php');
        } else {
            echo "<p>Credenciales incorrectas</p>";
            $this->loginForm();
        }
    }

    public function logout() {
        session_destroy();
        header('Location: index.php?accion=login');
    }
}
?>