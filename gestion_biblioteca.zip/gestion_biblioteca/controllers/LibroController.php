<?php
require_once(__DIR__ . '/../models/LibroModel.php');

class LibroController {
    private $modelo;

    public function __construct() {
        $this->modelo = new LibroModel();
    }

    public function listar() {
        $libros = $this->modelo->obtenerTodos();
        require_once(__DIR__ . '/../views/libros/listar.php');
    }

    public function agregar() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $titulo = $_POST['titulo'];
            $autor = $_POST['autor'];
            $isbn = $_POST['isbn'];

            if ($this->modelo->agregar($titulo, $autor, $isbn)) {
                header('Location: index.php?accion=listar_libros');
                exit;
            } else {
                echo "Error al agregar el libro.";
            }
        } else {
            require_once(__DIR__ . '/../views/libros/agregar.php');
        }
    }
}
?>